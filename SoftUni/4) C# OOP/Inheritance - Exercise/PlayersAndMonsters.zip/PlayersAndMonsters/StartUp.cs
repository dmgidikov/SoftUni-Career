﻿using PlayersAndMonsters.Elfs;
using PlayersAndMonsters.Wizards;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}