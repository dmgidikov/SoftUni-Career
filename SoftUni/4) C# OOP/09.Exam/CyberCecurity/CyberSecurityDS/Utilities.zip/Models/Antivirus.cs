﻿namespace CyberSecurityDS.Models
{
    public class Antivirus : DefensiveSoftware
    {
        public Antivirus(string name, int effectiveness) 
            : base(name, effectiveness)
        {
        }
    }
}