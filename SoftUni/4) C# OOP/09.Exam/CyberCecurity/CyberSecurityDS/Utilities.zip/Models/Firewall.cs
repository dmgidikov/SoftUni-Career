﻿namespace CyberSecurityDS.Models
{
    public class Firewall : DefensiveSoftware
    {
        public Firewall(string name, int effectiveness)
            : base(name, effectiveness)
        {
        }
    }
}