﻿namespace BorderControl
{
    public class StartUp
    {
        public static void Main()
        {
            var citizens = new List<Citizen>();
            var robots = new List<Robot>(); 

            while (true)
            {
                var input = Console.ReadLine().Split();

                if (input[0] == "End")
                {
                    break;
                }

                if (input.Length == 2)
                {
                    var robot = new Robot(input[0], input[1]);
                    robots.Add(robot);
                }
                else if (input.Length == 3)
                {
                    var citizen = new Citizen(input[0], int.Parse(input[1]), input[2]);
                    citizens.Add(citizen);
                }
            }

            var fakeID = Console.ReadLine();

            foreach (var citizen in citizens)
            {
                if (citizen.Id.EndsWith(fakeID))
                {
                    Console.WriteLine(citizen.Id);
                }
            }

            foreach (var robot in robots)
            {
                if (robot.Id.EndsWith(fakeID))
                {
                    Console.WriteLine(robot.Id);
                }
            }
        }
    }
}