﻿namespace Stealer
{
    using System.Reflection;

    public class StartUp
    {
        public static void Main()
        {
            var spy = new Spy();

            var result = spy.GetSettersAndGetters("Hacker");

            Console.WriteLine(result);
        }
    }
}