﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseHero.Common
{
    public static class ExceptionMessages
    {
        public static string InvalidHeroTypeInput = "Invalid hero!";
    }
}
