﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFarm.Common
{
    public class Exceptions
    {
        public static string FOOD_EXCEPTION = "{0} does not eat {1}";
    }
}
